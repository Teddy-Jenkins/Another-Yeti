Get Ready for some Industrial Petting!

To launch the game normally (non-VR), just start up industrial-petting.exe
To launch the game in VR, just use the (Launch in VR) shortcut

Any tutorial is missing at the moment, and things are a little rough around the edges, but the game's currently playable in both VR and non-VR!

To figure out what your next objectives are, look on the menu. Hit (Tab) normally, use the Menu tool in VR.
To see how to build a pet part (like an eyeball), look under the "Parts" tab in the menu.
To switch the pet that the assemblers are assembling:

  -in VR, choose the inspector tool and point it at an assembler, then press the trackpad
  -on flatscreens, look at an assembler and press "F" to inspect it, then press X

Faster movers and bigger junctions can be unlocked with cash on the "Structures" tab.

Copyright Another Yeti Inc, 2017
